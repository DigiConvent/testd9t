'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'barcode';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f02a';
var svgPathData = 'M0 32l16 0 0 448L0 480 0 32zm256 0l16 0 0 448-16 0 0-448zm144 0l0 448-16 0 0-448 16 0zm-96 0l16 0 0 448-16 0 0-448zM64 32l0 448-16 0L48 32l16 0zm384 0l16 0 0 448-16 0 0-448zm64 0l0 448-16 0 0-448 16 0zM112 32l16 0 0 448-16 0 0-448zm88 0l0 448-16 0 0-448 16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarcode = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;