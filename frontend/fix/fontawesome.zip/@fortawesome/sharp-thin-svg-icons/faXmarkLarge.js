'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'xmark-large';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e59b';
var svgPathData = 'M224 267.3L13.7 477.7 2.3 466.3 212.7 256 2.3 45.7 13.7 34.3 224 244.7 434.3 34.3l11.3 11.3L235.3 256 445.7 466.3l-11.3 11.3L224 267.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faXmarkLarge = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;