'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'flask';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f0c3';
var svgPathData = 'M288 219.9l2.8 4.1 66.4 96L90.7 320l66.4-96 2.8-4.1 0-5L160 16l128 0 0 198.9 0 5zM368.3 336L432 427.9l0 68.1L16 496l0-68.1L79.7 336l.3 0 288 0 .3 0zM304 214.9L304 16l24 0 8 0 0-16-8 0L304 0 288 0 160 0 144 0 120 0l-8 0 0 16 8 0 24 0 0 198.9L0 422.9 0 496l0 16 16 0 416 0 16 0 0-16 0-73.1-144-208z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFlask = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;