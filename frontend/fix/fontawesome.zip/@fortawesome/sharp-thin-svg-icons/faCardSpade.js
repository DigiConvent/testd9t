'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'card-spade';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e3ec';
var svgPathData = 'M16 16l0 480 352 0 0-480L16 16zM0 0L16 0 368 0l16 0 0 16 0 480 0 16-16 0L16 512 0 512l0-16L0 16 0 0zM192 120.9l5.7 5.7 39.6 39.6L297 225.9c25 25 25 65.5 0 90.5s-65.5 25-90.5 0l-6.5-6.5 0 56.1 24 0 8 0 0 16-8 0-24 0-16 0-24 0-8 0 0-16 8 0 24 0 0-56.1-6.5 6.5c-25 25-65.5 25-90.5 0s-25-65.5 0-90.5l59.7-59.7 39.6-39.6 5.7-5.7zm0 22.6l-33.9 33.9L98.3 237.2c-18.7 18.7-18.7 49.1 0 67.9s49.1 18.7 67.9 0l20.1-20.1 5.7-5.7 5.7 5.7 20.1 20.1c18.7 18.7 49.1 18.7 67.9 0s18.7-49.1 0-67.9l-59.7-59.7L192 143.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCardSpade = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;