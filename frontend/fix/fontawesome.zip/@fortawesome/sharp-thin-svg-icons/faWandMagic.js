'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'wand-magic';
var width = 512;
var height = 512;
var aliases = ["magic"];
var unicode = 'f0d0';
var svgPathData = 'M80 512l11.3-11.3L500.7 91.3 512 80 500.7 68.7 443.3 11.3 432 0 420.7 11.3 11.3 420.7 0 432l11.3 11.3 57.4 57.4L80 512zM432 22.6L489.4 80l-135 135L297 157.7l135-135zM285.7 169L343 226.3 80 489.4 22.6 432l263-263z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWandMagic = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;