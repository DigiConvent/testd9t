'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'y';
var width = 384;
var height = 512;
var aliases = [121];
var unicode = '59';
var svgPathData = 'M184 290.5L2.5 32l19.5 0L192 274.1 361.9 32l19.5 0L200 290.5 200 472l0 8-16 0 0-8 0-181.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faY = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;