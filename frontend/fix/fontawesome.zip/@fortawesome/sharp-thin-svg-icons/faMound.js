'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'mound';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e52d';
var svgPathData = 'M547.7 400L28.3 400 156.3 186.6C184.1 140.3 234.1 112 288 112s103.9 28.3 131.7 74.6L547.7 400zm18.7 0l-133-221.7C402.7 127.2 347.6 96 288 96s-114.7 31.2-145.4 82.3L9.6 400 0 416l18.7 0 538.7 0 18.7 0-9.6-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMound = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;