'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'turn-right';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e639';
var svgPathData = 'M336 256l-16 0L96 256l-16 0 0 16 0 192-64 0 0-272 304 0 16 0 0-16 0-96 9.4 0 144 144-144 144-9.4 0 0-96 0-16zm16 128L500.7 235.3 512 224l-11.3-11.3L352 64l-16 0-16 0 0 16 0 80 0 16-16 0L16 176 0 176l0 16L0 464l0 16 16 0 64 0 16 0 0-16 0-176 0-16 16 0 192 0 16 0 0 16 0 80 0 16 16 0 16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTurnRight = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;