'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'snooze';
var width = 448;
var height = 512;
var aliases = [128164,"zzz"];
var unicode = 'f880';
var svgPathData = 'M160 0l8 0L312 0l8 0 0 8 0 8 0 3.9-3.1 2.4L181 128l131 0 8 0 0 16-8 0-144 0-8 0 0-8 0-8 0-3.9 3.1-2.4L299 16 168 16l-8 0 0-16zM0 256l8 0 208 0 8 0 0 8 0 8 0 3.1-2.1 2.3L18.9 496 216 496l8 0 0 16-8 0L8 512l-8 0 0-8 0-8 0-3.1 2.1-2.3L205.1 272 8 272l-8 0 0-16zm296-32l144 0 8 0 0 8 0 8 0 3.3-2.3 2.3L307.3 384 440 384l8 0 0 16-8 0-144 0-8 0 0-8 0-8 0-3.3 2.3-2.3L428.7 240 296 240l-8 0 0-16 8 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSnooze = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;