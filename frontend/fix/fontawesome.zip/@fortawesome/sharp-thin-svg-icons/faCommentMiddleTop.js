'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'comment-middle-top';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e14a';
var svgPathData = 'M310.2 116.8l-3.6-5.8L256 30.2l-50.5 80.9-3.6 5.8-6.7 1.4C89.8 140.3 16 216.9 16 304c0 103.1 104.2 192 240 192s240-88.9 240-192c0-87.1-73.8-163.7-179.2-185.8l-6.7-1.4zM246.6 15.1L256 0l9.4 15.1 54.7 87.5C430.5 125.7 512 207.1 512 304c0 114.9-114.6 208-256 208S0 418.9 0 304c0-96.9 81.5-178.3 191.9-201.4l54.7-87.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCommentMiddleTop = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;