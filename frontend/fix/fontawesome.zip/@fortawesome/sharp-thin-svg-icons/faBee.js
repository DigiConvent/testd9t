'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'bee';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e0b2';
var svgPathData = 'M233.8 53.1L194.3 13.7 205.7 2.3l40 40c.4 .4 .7 .8 1 1.2C258.7 36.2 272.9 32 288 32s29.3 4.2 41.4 11.5c.3-.4 .6-.8 1-1.2l40-40 11.3 11.3L342.2 53.1C358.1 67.8 368 88.7 368 112c0 3-.2 6-.5 8.9C390.3 105 419 96 448 96c65 0 128 44.9 128 112c0 61.9-53.6 104.9-112.9 111.2c.6-5.1 .9-10.2 .9-15.2l0-1c52.4-6.5 96-44.6 96-95c0-55.4-52.8-96-112-96c-45.2 0-86.6 23.6-103.7 59.4c51.6 21.9 87.7 73 87.7 132.6c0 96-144 208-144 208s-144-112-144-208c0-59.6 36.2-110.7 87.7-132.6C214.6 135.6 173.2 112 128 112c-59.2 0-112 40.6-112 96c0 50.4 43.6 88.5 96 95l0 1c0 5 .3 10.1 .9 15.2C53.6 312.9 0 269.9 0 208C0 140.9 63 96 128 96c29 0 57.7 9 80.5 24.9c-.3-2.9-.5-5.9-.5-8.9c0-23.3 9.9-44.2 25.8-58.9zm17.8 111.5c11.6-3 23.8-4.6 36.4-4.6s24.8 1.6 36.4 4.6C341.1 153.1 352 133.8 352 112c0-35.3-28.7-64-64-64s-64 28.7-64 64c0 21.8 10.9 41.1 27.6 52.6zM169.3 256c-6 14.8-9.3 31-9.3 48l256 0c0-17-3.3-33.2-9.3-48l-237.4 0zm7.8-16l221.8 0c-22.1-38.3-63.5-64-110.9-64s-88.7 25.7-110.9 64zm237.4 80l-253 0c2.7 15.3 9.2 31.5 18.3 48l216.4 0c9.2-16.5 15.6-32.7 18.3-48zm-28 64l-197.1 0c11 16.9 24 33.1 37.3 48l122.5 0c13.3-14.9 26.3-31.1 37.3-48zm-52.2 64l-92.8 0c12.7 13.1 24.8 24.4 34.5 33c4.5 4 8.6 7.5 11.9 10.3c3.3-2.8 7.3-6.2 11.9-10.3c9.7-8.6 21.8-19.9 34.5-33z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;