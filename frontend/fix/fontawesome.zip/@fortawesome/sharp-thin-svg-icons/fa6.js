'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = '6';
var width = 320;
var height = 512;
var aliases = [];
var unicode = '36';
var svgPathData = 'M16 320a144 144 0 1 1 288 0A144 144 0 1 1 16 320zm84.6-148.6L234.8 32l-22.2 0L46.6 204.4C16.7 235.4 0 276.9 0 320c0 88.4 71.6 160 160 160s160-71.6 160-160s-71.6-160-160-160c-21 0-41.1 4-59.4 11.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.fa6 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;