'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'circle-caret-up';
var width = 512;
var height = 512;
var aliases = ["caret-circle-up"];
var unicode = 'f331';
var svgPathData = 'M256 16a240 240 0 1 1 0 480 240 240 0 1 1 0-480zm0 496A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM128 320l16 0 224 0 16 0 0-16 0-24L256 160 128 280l0 24 0 16zm240-33.1l0 17.1-224 0 0-17.1 112-105 112 105z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCircleCaretUp = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;