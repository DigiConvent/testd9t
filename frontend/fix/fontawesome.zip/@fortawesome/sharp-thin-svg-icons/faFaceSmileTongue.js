'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'face-smile-tongue';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e394';
var svgPathData = 'M16 256C16 123.5 123.5 16 256 16s240 107.5 240 240c0 10.5-.7 20.8-2 31l15.9 2c1.4-10.8 2.1-21.8 2.1-33C512 114.6 397.4 0 256 0S0 114.6 0 256S114.6 512 256 512c48.3 0 93.6-13.4 132.1-36.7l-8.3-13.7C343.7 483.4 301.3 496 256 496C123.5 496 16 388.5 16 256zm404.1 25.1l-9.1-5.3-2.7 10.2C389.4 356.7 328.1 408 256 408s-133.4-51.3-152.3-122.1l-15.5 4.1C108.8 367.1 175.9 424 256 424c31.3 0 60.6-8.7 85.9-23.8l56.4 34.3c33.8 20.6 78 9.3 97.8-25c19.7-34.1 8.6-78.4-25.5-98.5l-50.5-29.7zM406.6 420.7l-50.1-30.4c29.5-22.1 52.2-53.6 64.2-90.2l41.7 24.5c26.4 15.6 35.2 50 19.8 76.7c-15.3 26.5-49.4 35.3-75.6 19.4zm-255.7-235c7.6-11.6 16.1-17.7 24.9-17.7s17.3 6.1 24.9 17.7c7.4 11.4 12.7 26.3 15.2 39.8l15.7-2.9c-2.8-15-8.7-32-17.6-45.6c-8.7-13.3-21.5-25-38.3-25s-29.6 11.7-38.3 25c-8.8 13.5-14.8 30.6-17.6 45.6l15.7 2.9c2.5-13.5 7.8-28.4 15.2-39.8zm144.8 39.8c2.5-13.5 7.8-28.4 15.2-39.8c7.6-11.6 16.1-17.7 24.9-17.7s17.3 6.1 24.9 17.7c7.4 11.4 12.7 26.3 15.2 39.8l15.7-2.9c-2.8-15-8.7-32-17.6-45.6c-8.7-13.3-21.5-25-38.3-25s-29.6 11.7-38.3 25c-8.8 13.5-14.8 30.6-17.6 45.6l15.7 2.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFaceSmileTongue = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;