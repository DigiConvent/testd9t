'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'arrow-down-small-big';
var width = 576;
var height = 512;
var aliases = ["sort-size-down-alt"];
var unicode = 'f88d';
var svgPathData = 'M160 475.3l5.7-5.7 104-104 5.7-5.7L264 348.7l-5.7 5.7L168 444.7 168 40l0-8-16 0 0 8 0 404.7L61.7 354.3 56 348.7 44.7 360l5.7 5.7 104 104 5.7 5.7zM336 192l128 0 16 0 0-16 0-128 0-16-16 0L336 32l-16 0 0 16 0 128 0 16 16 0zm128-16l-128 0 0-128 128 0 0 128zM320 480l16 0 192 0 16 0 0-16 0-192 0-16-16 0-192 0-16 0 0 16 0 192 0 16zM528 272l0 192-192 0 0-192 192 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownSmallBig = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;