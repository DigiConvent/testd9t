'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'arrow-left-from-line';
var width = 448;
var height = 512;
var aliases = [8612,"arrow-from-right"];
var unicode = 'f344';
var svgPathData = 'M8 252.7l-5.7 5.7L8 264 144 400l5.7 5.7L161 394.3l-5.7-5.7L33 266.3l308.7 0 8 0 0-16-8 0L33 250.3 155.3 128l5.7-5.7L149.7 111l-5.7 5.7L8 252.7zM429.7 442.3l0 8 16 0 0-8 0-368 0-8-16 0 0 8 0 368z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowLeftFromLine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;