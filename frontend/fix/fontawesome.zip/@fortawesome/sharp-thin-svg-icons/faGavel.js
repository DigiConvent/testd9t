'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'gavel';
var width = 512;
var height = 512;
var aliases = ["legal"];
var unicode = 'f0e3';
var svgPathData = 'M304.1 11.2l-5.7 5.7L291.3 24 488 220.7l7.1-7.1 5.7-5.7 11.3 11.3-5.7 5.7-12.8 12.8-112 112s0 0 0 0l-12.8 12.8-5.7 5.7-11.3-11.3 5.7-5.7 7.1-7.1L168 147.3l-7.1 7.1-5.7 5.7-11.3-11.3 5.7-5.7 12.8-12.8 112-112L287.1 5.5l5.7-5.7 11.3 11.3zM179.3 136L376 332.7 476.7 232 280 35.3 179.3 136zm-72 364.7L96 512 84.7 500.7 11.3 427.3 0 416l11.3-11.3L132.7 283.3 144 272l11.3 11.3 31 31 51.7-51.7 11.3 11.3-51.7 51.7 31 31L240 368l-11.3 11.3L107.3 500.7zM217.4 368L144 294.6 22.6 416 96 489.4 217.4 368z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGavel = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;