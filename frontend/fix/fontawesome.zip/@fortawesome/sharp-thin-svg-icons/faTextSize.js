'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'text-size';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f894';
var svgPathData = 'M8 32L0 32l0 8 0 64 0 8 16 0 0-8 0-56 168 0 0 416-80 0-8 0 0 16 8 0 88 0 88 0 8 0 0-16-8 0-80 0 0-416 168 0 0 56 0 8 16 0 0-8 0-64 0-8-8 0L192 32 8 32zM328 224l-8 0 0 8 0 64 0 8 16 0 0-8 0-56 136 0 0 224-80 0-8 0 0 16 8 0 88 0 88 0 8 0 0-16-8 0-80 0 0-224 136 0 0 56 0 8 16 0 0-8 0-64 0-8-8 0-152 0-152 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTextSize = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;