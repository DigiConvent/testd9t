'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'kip-sign';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e1c4';
var svgPathData = 'M96 32l0 8 0 198.8 234.9-197 6.1-5.1L347.3 49l-6.1 5.1L110 248l266 0 8 0 0 16-8 0-266 0L341.1 457.9l6.1 5.1L337 475.3l-6.1-5.1L96 273.2 96 473l0 8-16 0 0-8 0-209L8 264l-8 0 0-16 8 0 72 0L80 40l0-8 16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faKipSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;