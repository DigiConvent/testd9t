'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'folder-gear';
var width = 512;
var height = 512;
var aliases = ["folder-cog"];
var unicode = 'e187';
var svgPathData = 'M224 32l48 64 224 0 16 0 0 16 0 352 0 16-16 0L16 480 0 480l0-16L0 48 0 32l16 0 208 0zm48 80l-8 0-4.8-6.4L216 48 16 48l0 416 480 0 0-352-224 0zm-48 48l8 0 48 0 8 0 0 8 0 29.6c11 4.4 20.9 10.2 30.3 17.5l25.6-14.8 6.9-4 4 6.9 24 41.6 4 6.9-6.9 4-25.6 14.8c.9 5.6 1.6 11.5 1.6 17.5s-.7 11.9-1.6 17.5l25.6 14.8 6.9 4-4 6.9-24 41.6-4 6.9-6.9-4-25.6-14.8c-9.3 7.3-19.2 13.1-30.3 17.5l0 29.6 0 8-8 0-48 0-8 0 0-8 0-29.6c-11-4.4-20.9-10.2-30.3-17.5l-25.6 14.8-6.9 4-4-6.9-24-41.6-4-6.9 6.9-4 25.6-14.8c-.9-5.6-1.6-11.5-1.6-17.5s.7-11.9 1.6-17.5l-25.6-14.8-6.9-4 4-6.9 24-41.6 4-6.9 6.9 4 25.6 14.8c9.3-7.3 19.2-13.1 30.3-17.5l0-29.6 0-8zm16 16l0 27.1 0 5.7-5.3 1.9c-13.1 4.6-24.3 11.1-34.9 20.2l-4.3 3.7-4.9-2.8L167 218.1l-16 27.7 23.5 13.6 4.9 2.8-1 5.6c-1.3 7.1-2.4 13.7-2.4 20.2s1 13.1 2.4 20.2l1 5.6-4.9 2.8L151 330.1l16 27.7 23.5-13.6 4.9-2.8 4.3 3.7c10.6 9.1 21.8 15.6 34.9 20.2l5.3 1.9 0 5.7 0 27.1 32 0 0-27.1 0-5.7 5.3-1.9c13.2-4.6 24.3-11.1 34.9-20.2l4.3-3.7 4.9 2.8L345 357.9l16-27.7-23.5-13.6-4.9-2.8 1-5.6c1.3-7.1 2.4-13.7 2.4-20.2s-1-13.1-2.4-20.2l-1-5.6 4.9-2.8L361 245.9l-16-27.7-23.5 13.6-4.9 2.8-4.3-3.7c-10.6-9.1-21.8-15.6-34.9-20.2l-5.3-1.9 0-5.7 0-27.1-32 0zm16 136a24 24 0 1 0 0-48 24 24 0 1 0 0 48zm0-64a40 40 0 1 1 0 80 40 40 0 1 1 0-80z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFolderGear = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;