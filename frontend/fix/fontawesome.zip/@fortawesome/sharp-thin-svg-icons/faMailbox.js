'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'mailbox';
var width = 576;
var height = 512;
var aliases = [128234];
var unicode = 'f813';
var svgPathData = 'M272 432L16 432l0-224C16 137.3 73.3 80 144 80s128 57.3 128 128l0 224zm16-224c0-55.7-31.7-104.1-78-128l222 0c70.7 0 128 57.3 128 128l0 224-272 0 0-224zM272 448l16 0 272 0 16 0 0-16 0-224c0-79.5-64.5-144-144-144L144 64C64.5 64 0 128.5 0 208L0 432l0 16 16 0 256 0zM72 192l-8 0 0 16 8 0 144 0 8 0 0-16-8 0L72 192zm304 0l-8 0 0 16 8 0 56 0 0 80 0 8 8 0 64 0 8 0 0-8 0-88 0-8-8 0-64 0-64 0zm72 88l0-72 48 0 0 72-48 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMailbox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;