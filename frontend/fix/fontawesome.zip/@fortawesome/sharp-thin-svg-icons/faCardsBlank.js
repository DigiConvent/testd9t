'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'cards-blank';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e4df';
var svgPathData = 'M443.1 359.5L216.8 490.1 21.9 152.5 248.1 21.9 443.1 359.5zM240.1 8L0 146.7 202.9 498.1l8 13.9 13.9-8L451.1 373.4l13.9-8-8-13.9L262 13.9 254 0 240.1 8zM320 496l0 16 16 0 288 0 16 0 0-16 0-416 0-16-16 0L327.9 64l9.2 16L624 80l0 416-288 0 0-19.3L320 486l0 10z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCardsBlank = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;