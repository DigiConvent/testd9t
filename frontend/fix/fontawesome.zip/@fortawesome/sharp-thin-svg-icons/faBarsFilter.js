'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'bars-filter';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e0ad';
var svgPathData = 'M0 80l448 0 0 16L0 96 0 80zM64 240l320 0 0 16L64 256l0-16zM288 400l0 16-128 0 0-16 128 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBarsFilter = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;