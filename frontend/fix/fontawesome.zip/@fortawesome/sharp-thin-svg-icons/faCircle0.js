'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'circle-0';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0ed';
var svgPathData = 'M256 16a240 240 0 1 1 0 480 240 240 0 1 1 0-480zm0 496A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-384c-53 0-96 43-96 96l0 64c0 53 43 96 96 96s96-43 96-96l0-64c0-53-43-96-96-96zm-80 96c0-44.2 35.8-80 80-80s80 35.8 80 80l0 64c0 44.2-35.8 80-80 80s-80-35.8-80-80l0-64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCircle0 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;