'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'sportsball';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e44b';
var svgPathData = 'M266.8 37.6c53.1-10.3 116.6-10.6 192 2l1.9 .3L331.1 169.6c-33.5-35.7-56.5-81.3-64.2-132zm-1.9-15.9s0 0 0 0c-5.3 1-10.6 2.1-15.8 3.4c0 0 0 0 0 0c-14.1 3.3-27.5 7.4-40.3 12.1C169 52 136.3 73.2 110 98.6c0 0 0 0 0 0c-3.9 3.7-7.6 7.6-11.2 11.5c0 0 0 0 0 0C86.3 123.7 75.4 138.3 66 153.6c-18.4 29.9-31 62.5-39.2 95.7c0 0 0 0 0 0c-1.3 5.2-2.5 10.5-3.6 15.7c0 0 0 0 0 0c-14.6 70.8-10.1 143.1 1.2 198l4.4 21.5 21.6 3.6c103.9 17.4 187 11 252.6-13.3c66-24.5 112.2-66.5 142.9-116.5c60.2-98.2 59.1-224.7 41.6-309.5l-4.4-21.5-21.6-3.6c-76.3-12.7-141.4-12.7-196.6-2.2zM39.2 267.1c50 7.9 95.1 30.8 130.5 64L40.2 460.4l-.1-.6c-11.1-53.9-15.3-124.4-1-192.8zm12.1 205L180.9 342.4c33.5 35.7 56.5 81.3 64.2 132c-53.1 10.3-116.6 10.6-192-2l-1.9-.3zM260.8 471c-8.4-53.7-33-102.1-68.6-139.9L256 267.3 390.7 402c-24.8 23.9-55.5 43.8-93.2 57.8c-11.6 4.3-23.8 8-36.7 11.1zm141.1-80.4L267.3 256l63.8-63.8c37.4 35.2 85.1 59.7 138.2 68.3c-7.9 31.2-19.8 61.6-36.9 89.5c-8.8 14.3-18.9 27.9-30.4 40.5zm71-145.7c-50-7.9-95.1-30.8-130.5-64L471.8 51.5l.1 .6c11.1 53.9 15.3 124.4 1 192.8zM42.8 251.4c7.9-31.2 19.8-61.6 36.9-89.5c8.8-14.3 18.9-27.9 30.4-40.5L244.7 256l-63.8 63.8c-37.4-35.2-85.1-59.7-138.2-68.3zM121.3 110c24.8-23.9 55.5-43.8 93.2-57.8c11.6-4.3 23.8-8 36.7-11.1c8.4 53.7 33 102.1 68.6 139.9L256 244.7 121.3 110z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSportsball = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;