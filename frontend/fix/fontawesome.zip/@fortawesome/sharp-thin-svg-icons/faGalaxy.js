'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'galaxy';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e008';
var svgPathData = 'M128 184c0-92.8 75.2-168 168-168l27.3 0-9.8 8.9c-31.4 28.6-52.7 66.1-61.2 107l-3.1 14.9 14-5.9c19.9-8.3 41.8-13 64.8-13c92.8 0 168 75.2 168 168l0 27.3-8.9-9.8c-28.6-31.4-66.1-52.7-107-61.2l-14.9-3.1 5.9 14c8.3 19.9 13 41.8 13 64.8c0 92.8-75.2 168-168 168l-27.3 0 9.8-8.9c31.4-28.6 52.7-66.1 61.2-107l3.1-14.9-14 5.9c-19.9 8.3-41.8 13-64.8 13C91.2 384 16 308.8 16 216l0-27.3 8.9 9.8c28.6 31.4 66.1 52.7 107 61.2l14.9 3.1-5.9-14c-8.3-19.9-13-41.8-13-64.8zM296 0C194.4 0 112 82.4 112 184c0 19.7 3.1 38.7 8.8 56.5c-32-9.4-61.2-27.5-84-52.7L13.9 162.6 0 147.3 0 168l0 48C0 317.6 82.4 400 184 400c19.7 0 38.7-3.1 56.5-8.8c-9.4 32-27.5 61.2-52.7 84l-25.2 22.9L147.3 512l20.7 0 48 0c101.6 0 184-82.4 184-184c0-19.7-3.1-38.7-8.8-56.5c32 9.4 61.2 27.5 84 52.7l22.9 25.2L512 364.7l0-20.7 0-48c0-101.6-82.4-184-184-184c-19.7 0-38.7 3.1-56.5 8.8c9.4-32 27.5-61.2 52.7-84l25.2-22.9L364.7 0 344 0 296 0zM244.7 307.3L256 318.6l11.3-11.3 40-40L318.6 256l-11.3-11.3-40-40L256 193.4l-11.3 11.3-40 40L193.4 256l11.3 11.3 40 40zM256 296l-11.3-11.3-17.4-17.4L216 256l11.3-11.3 17.4-17.4L256 216l11.3 11.3 17.4 17.4L296 256l-11.3 11.3-17.4 17.4L256 296z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGalaxy = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;