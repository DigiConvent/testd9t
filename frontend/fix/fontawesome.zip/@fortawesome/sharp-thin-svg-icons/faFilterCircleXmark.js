'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'filter-circle-xmark';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e17b';
var svgPathData = 'M208 282.1l0 5.9 0 72.7 52.2 45.7c2.3 10.2 5.4 20 9.4 29.4L192 368l0-80L0 64 0 16 0 0 16 0 496 0l16 0 0 16 0 48L399.8 194.9c-9.4 1.7-18.6 4.2-27.4 7.4L496 58.1 496 16 16 16l0 42.1L204.1 277.6l3.9 4.5zM560 368a128 128 0 1 0 -256 0 128 128 0 1 0 256 0zm-272 0a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm205.7-50.3L443.3 368l50.3 50.3 5.7 5.7L488 435.3l-5.7-5.7L432 379.3l-50.3 50.3-5.7 5.7L364.7 424l5.7-5.7L420.7 368l-50.3-50.3-5.7-5.7L376 300.7l5.7 5.7L432 356.7l50.3-50.3 5.7-5.7L499.3 312l-5.7 5.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFilterCircleXmark = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;