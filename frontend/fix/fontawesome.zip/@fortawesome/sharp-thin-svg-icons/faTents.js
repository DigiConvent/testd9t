'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'tents';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e582';
var svgPathData = 'M236.1 120L416 0 608 128l29.5 192 2.5 16-16.2 0-160.5 0L461 320l160.4 0L593.3 137.4 416 19.2 250.5 129.6l-4.3-2.9L236.1 120zM16.2 512L0 512l2.3-16L32 288 224 160 416 288l29.7 208 2.3 16-16.2 0L16.2 512zm305.6-16L232 348.5 232 496l89.8 0zM216 184.6L46.8 297.3 18.4 496 216 496l0-311.4zM401.2 297.3L232 184.6l0 133.2L340.5 496l89.1 0L401.2 297.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTents = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;