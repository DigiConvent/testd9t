'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'bookmark';
var width = 384;
var height = 512;
var aliases = [128278,61591];
var unicode = 'f02e';
var svgPathData = 'M192 381.5l8.1 4.7 167.9 98L368 16 16 16l0 468.1 167.9-98 8.1-4.7zM16 502.7L0 512l0-18.5L0 16 0 0 16 0 368 0l16 0 0 16 0 477.5 0 18.5-16-9.3L192 400 16 502.7z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookmark = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;