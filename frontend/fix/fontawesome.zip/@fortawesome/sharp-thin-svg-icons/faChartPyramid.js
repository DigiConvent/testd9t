'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'chart-pyramid';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e0e6';
var svgPathData = 'M9.1 464L0 480l18.4 0 475.1 0 18.4 0-9.1-16L265.2 48.1 256 32l-9.2 16.1L9.1 464zm329-256l-164.3 0L256 64.2 338.1 208zm9.1 16l64 112-310.6 0 64-112 182.6 0zm73.1 128l64 112L27.6 464l64-112 328.9 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faChartPyramid = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;