'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'text-slash';
var width = 640;
var height = 512;
var aliases = ["remove-format"];
var unicode = 'f87d';
var svgPathData = 'M16.2 5L9.9 0 0 12.5l6.3 5L623.8 507l6.3 5 9.9-12.5-6.3-5L16.2 5zM348.8 187L390 48l167.8 0-16 64 16.5 0 17.5-70.1 2.5-9.9L568 32 384.2 32l-.4 0L168 32l-6.2 0-1.5 6.1c0 0 0 0 0 .1L174 49l.2-1 199 0-38 128.3L348.8 187zM304.7 335.7L291.2 325 250 464l-82 0-8 0 0 16 8 0 87.8 0 .4 0 87.8 0 8 0 0-16-8 0-77.3 0 38-128.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTextSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;