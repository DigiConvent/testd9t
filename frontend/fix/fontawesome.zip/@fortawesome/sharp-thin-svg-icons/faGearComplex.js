'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'gear-complex';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e5e9';
var svgPathData = 'M319.7 12.9L317.1 0 304 0 208 0 194.9 0l-2.6 12.9-9.7 48.5c-4.2 1.6-8.3 3.3-12.4 5.1L129.1 39l-10.9-7.3L108.9 41 41 108.9l-9.3 9.3L39 129.1l27.4 41.1c-1.8 4.1-3.6 8.2-5.1 12.4l-48.5 9.7L0 194.9 0 208l0 96 0 13.1 12.9 2.6 48.5 9.7c1.6 4.2 3.3 8.3 5.1 12.4L39 382.9l-7.3 10.9 9.3 9.3L108.9 471l9.3 9.3 10.9-7.3 41.1-27.4c4.1 1.8 8.2 3.6 12.4 5.1l9.7 48.5 2.6 12.9 13.1 0 96 0 13.1 0 2.6-12.9 9.7-48.5c4.2-1.6 8.3-3.3 12.4-5.1L382.9 473l10.9 7.3 9.3-9.3L471 403.1l9.3-9.3L473 382.9l-27.4-41.1c1.8-4.1 3.6-8.2 5.1-12.4l48.5-9.7 12.9-2.6 0-13.1 0-96 0-13.1-12.9-2.6-48.5-9.7c-1.6-4.2-3.3-8.3-5.1-12.4L473 129.1l7.3-10.9-9.3-9.3L403.1 41l-9.3-9.3L382.9 39 341.8 66.5c-4.1-1.8-8.2-3.6-12.4-5.1l-9.7-48.5zm-150.7 72c8.8-4.5 18-8.3 27.6-11.4L208 16l96 0 11.5 57.4c9.5 3.1 18.8 6.9 27.6 11.4l48.7-32.5 67.9 67.9-32.5 48.7c4.5 8.8 8.3 18 11.4 27.6L496 208l0 96-57.4 11.5c-3.1 9.5-6.9 18.8-11.4 27.6l32.5 48.7-67.9 67.9-48.7-32.5c-8.8 4.5-18 8.3-27.6 11.4L304 496l-96 0-11.5-57.4c-9.5-3.1-18.8-6.9-27.6-11.4l-48.7 32.5L52.4 391.8l32.5-48.7c-4.5-8.8-8.3-18-11.4-27.6L16 304l0-96 57.4-11.5c3.1-9.5 6.9-18.8 11.4-27.6L52.4 120.2l67.9-67.9 48.7 32.5zM176 256a80 80 0 1 1 160 0 80 80 0 1 1 -160 0zm176 0a96 96 0 1 0 -192 0 96 96 0 1 0 192 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faGearComplex = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;