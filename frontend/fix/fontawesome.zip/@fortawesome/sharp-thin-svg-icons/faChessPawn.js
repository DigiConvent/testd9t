'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'chess-pawn';
var width = 320;
var height = 512;
var aliases = [9823];
var unicode = 'f443';
var svgPathData = 'M256 144A96 96 0 1 0 64 144a96 96 0 1 0 192 0zm16 0c0 40.7-21.8 76.4-54.3 96l4.9 0 33.4 0 8 0 0 16-8 0-30.3 0 24.8 128-16.3 0L209.4 256 160 256l-49.4 0L85.8 384l-16.3 0L94.3 256 64 256l-8 0 0-16 8 0 33.4 0 4.9 0C69.8 220.4 48 184.7 48 144C48 82.1 98.1 32 160 32s112 50.1 112 112zM16 496l288 0 0-20.5L264.9 432 55.1 432 16 475.5 16 496zM0 496l0-26.7L48 416l224 0 48 53.3 0 26.7 0 16-16 0L16 512 0 512l0-16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faChessPawn = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;