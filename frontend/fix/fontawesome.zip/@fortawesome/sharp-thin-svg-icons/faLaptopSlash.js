'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'laptop-slash';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e1c7';
var svgPathData = 'M16.2 5L9.9 0 0 12.5l6.3 5L623.8 507l6.3 5 9.9-12.5-6.3-5L16.2 5zM487.3 480l-20.3-16L54.6 464 16 425.4 16 400l370 0-20.3-16L16 384 0 384l0 16 0 32 48 48 439.3 0zM560 352l16 0 0-304 0-16-16 0L152.3 32l20.3 16L560 48l0 304zM64 145.8L64 352l16 0 0-193.6L64 145.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faLaptopSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;