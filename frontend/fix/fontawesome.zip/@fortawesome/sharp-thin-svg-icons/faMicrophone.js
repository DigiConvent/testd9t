'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'microphone';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f130';
var svgPathData = 'M112 16l160 0 0 240c0 44.2-35.8 80-80 80s-80-35.8-80-80l0-240zM96 0l0 16 0 240c0 53 43 96 96 96s96-43 96-96l0-240 0-16L272 0 112 0 96 0zM48 200l0-8-16 0 0 8 0 56c0 85.7 67.4 155.6 152 159.8l0 80.2-80 0-8 0 0 16 8 0 88 0 88 0 8 0 0-16-8 0-80 0 0-80.2c84.6-4.2 152-74.1 152-159.8l0-56 0-8-16 0 0 8 0 56c0 79.5-64.5 144-144 144s-144-64.5-144-144l0-56z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMicrophone = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;