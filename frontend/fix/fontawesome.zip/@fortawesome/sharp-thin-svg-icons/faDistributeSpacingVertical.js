'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'distribute-spacing-vertical';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e366';
var svgPathData = 'M512 480l0-16L0 464l0 16 512 0zM112 368l0-224 288 0 0 224-288 0zm288 16l16 0 0-16 0-224 0-16-16 0-288 0-16 0 0 16 0 224 0 16 16 0 288 0zM0 48l512 0 0-16L0 32 0 48z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faDistributeSpacingVertical = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;