'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'pizza';
var width = 576;
var height = 512;
var aliases = [127829];
var unicode = 'f817';
var svgPathData = 'M425.7 86.3l-33.9 33.9-11.3 11.3L267.3 244.7 256 256l11.3 11.3L380.5 380.5l11.3 11.3 33.9 33.9L437 437c-3.8 3.8-7.7 7.4-11.7 11c-45.1 39.8-104.4 64-169.4 64C114.6 512 0 397.4 0 256S114.6 0 256 0c64.9 0 124.2 24.2 169.4 64c4 3.5 7.9 7.2 11.7 11L425.7 86.3zM414 75.4C371.8 38.4 316.5 16 256 16C123.5 16 16 123.5 16 256s107.5 240 240 240c60.5 0 115.8-22.4 158-59.4l-34-34C346.5 430.9 303.3 448 256 448C150 448 64 362 64 256S150 64 256 64c47.3 0 90.5 17.1 124 45.4l34-34zM256 80C158.8 80 80 158.8 80 256s78.8 176 176 176c42.8 0 82.1-15.3 112.6-40.7L244.7 267.3 233.4 256l11.3-11.3L368.6 120.7C338.1 95.3 298.8 80 256 80zM560 256c0-60.5-22.4-115.8-59.4-158l-34 34c28.3 33.5 45.4 76.7 45.4 124s-17.1 90.5-45.4 124l34 34c37-42.2 59.4-97.5 59.4-158zM455.3 143.4L342.6 256 455.3 368.6C480.7 338.1 496 298.8 496 256s-15.3-82.1-40.7-112.6zM501 437l-11.3-11.3-33.9-33.9-11.3-11.3L331.3 267.3 320 256l11.3-11.3L489.7 86.3 501 75c3.8 3.8 7.4 7.7 11 11.7c39.8 45.1 64 104.4 64 169.4s-24.2 124.2-64 169.4c-3.5 4-7.2 7.9-11 11.7zM144 256a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zm80-112a16 16 0 1 1 0 32 16 16 0 1 1 0-32zM208 352a16 16 0 1 1 32 0 16 16 0 1 1 -32 0zM448 240a16 16 0 1 1 0 32 16 16 0 1 1 0-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPizza = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;