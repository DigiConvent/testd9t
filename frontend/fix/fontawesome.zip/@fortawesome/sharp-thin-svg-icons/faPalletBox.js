'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'pallet-box';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e208';
var svgPathData = 'M496 16l0 256-352 0 0-256 112 0 0 108 0 20 16-12 48-36 48 36 16 12 0-20 0-108 112 0zM272 16l96 0 0 96L329.6 83.2 320 76l-9.6 7.2L272 112l0-96zM496 0L384 0 368 0 272 0 256 0 144 0 128 0l0 16 0 256 0 16 16 0 352 0 16 0 0-16 0-256 0-16L496 0zM0 352l0 16 8 0 72 0 0 128L8 496l-8 0 0 16 8 0 72 0 8 0 8 0 216 0 8 0 8 0 216 0 8 0 8 0 72 0 8 0 0-16-8 0-72 0 0-128 72 0 8 0 0-16-8 0-72 0-8 0-8 0-216 0-8 0-8 0L96 352l-8 0-8 0L8 352l-8 0zM96 496l0-128 216 0 0 128L96 496zm232 0l0-128 216 0 0 128-216 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPalletBox = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;