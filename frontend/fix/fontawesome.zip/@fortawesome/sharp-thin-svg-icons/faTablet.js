'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'tablet';
var width = 448;
var height = 512;
var aliases = ["tablet-android"];
var unicode = 'f3fb';
var svgPathData = 'M16 16l0 480 416 0 0-480L16 16zM0 0L16 0 432 0l16 0 0 16 0 480 0 16-16 0L16 512 0 512l0-16L0 16 0 0zM176 432l96 0 8 0 0 16-8 0-96 0-8 0 0-16 8 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTablet = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;