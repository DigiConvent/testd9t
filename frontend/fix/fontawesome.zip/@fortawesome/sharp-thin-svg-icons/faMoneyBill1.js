'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'money-bill-1';
var width = 576;
var height = 512;
var aliases = ["money-bill-alt"];
var unicode = 'f3d1';
var svgPathData = 'M560 80l0 352L16 432 16 80l544 0zM16 64L0 64 0 80 0 432l0 16 16 0 544 0 16 0 0-16 0-352 0-16-16 0L16 64zM544 184l0-16-8 0-8 0c-30.9 0-56-25.1-56-56l0-8 0-8-16 0 0 8 0 8c0 39.8 32.2 72 72 72l8 0 8 0zM40 184l8 0c39.8 0 72-32.2 72-72l0-8 0-8-16 0 0 8 0 8c0 30.9-25.1 56-56 56l-8 0-8 0 0 16 8 0zM544 328l-8 0-8 0c-39.8 0-72 32.2-72 72l0 8 0 8 16 0 0-8 0-8c0-30.9 25.1-56 56-56l8 0 8 0 0-16zM40 328l-8 0 0 16 8 0 8 0c30.9 0 56 25.1 56 56l0 8 0 8 16 0 0-8 0-8c0-39.8-32.2-72-72-72l-8 0zM288 144a112 112 0 1 1 0 224 112 112 0 1 1 0-224zm0 240a128 128 0 1 0 0-256 128 128 0 1 0 0 256zM272 200l-8 0 0 16 8 0 8 0 0 80-16 0-8 0 0 16 8 0 16 0 16 0 16 0 8 0 0-16-8 0-16 0 0-88 0-8-8 0-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMoneyBill1 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;