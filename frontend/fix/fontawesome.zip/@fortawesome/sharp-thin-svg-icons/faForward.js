'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'forward';
var width = 512;
var height = 512;
var aliases = [9193];
var unicode = 'f04e';
var svgPathData = 'M497.6 265.6L512 256l-14.4-9.6L240 74.7 224 64l0 19.2 0 115.2L16 73.6 0 64 0 82.7 0 429.3 0 448l16-9.6L224 313.6l0 115.2 0 19.2 16-10.7L497.6 265.6zM224 294.9L16 419.7 16 92.3 224 217.1l0 77.9zm16 123.2l0-324.2L483.2 256 240 418.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faForward = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;