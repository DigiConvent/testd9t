'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'horse-saddle';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'f8c3';
var svgPathData = 'M328 136c0-66.3 53.7-120 120-120l8 0 16 0 43.7 0 33.8 50.8 10 104.5-67.9 34-28.4-56.8-2.2-4.4-4.9 0-16 0-8 0 0 8 0 87.5 0 .2 0 .3c-.2 25.4-11.6 47.6-29.2 62.5l-2.8 2.4 0 3.7L400 496l-72 0 0-170.3 0-6.4-6.3-1.4L248 301.7l0-54c44.9-4 80-41.7 80-87.6l0-16 0-8zm-88 96c-39.8 0-72-32.2-72-72l0-16 23.8 0 56.2 0 64 0 0 16c0 39.8-32.2 72-72 72zm-8 15.6l0 50.5-30.3-6.6-9.7-2.1 0 9.9 0 4.7 0 40 0 8.2-3.2 7.5-17.4 40.5-1.1 2.6 .8 2.7L196.2 496l-83 0L89.5 410.7l-3.8-13.5 5.5-12.9 20.1-46.9 .6-1.5 0-1.6 0-19.8 0-1.7-.7-1.6L77.9 237.7c-3.9-8.6-5.9-18-5.9-27.4c0-36.6 29.7-66.3 66.3-66.3l13.7 0 0 16c0 45.9 35.1 83.6 80 87.6zM191.8 128L160 128l-21.7 0c-26.5 0-50.1 12.5-65.1 32L72 160l-8 0c-35.3 0-64 28.7-64 64l0 88 0 8 16 0 0-8 0-88c0-26.3 21.2-47.7 47.5-48c-4.8 10.4-7.5 22.1-7.5 34.3c0 11.7 2.5 23.4 7.4 34.1L96 316.1l0 16.4L76.5 377.9l-6.6 15.5L68.8 396l.8 2.7L74 415l25.3 91.2L101 512l6.1 0 99.6 0 10.5 0-2.8-10.1L187.2 404l16.2-37.9 3.9-9.1 .6-1.5 0-1.6 0-9.9 0-34.7 104 22.8L312 504l0 8 8 0 88 0 8 0 0-8 0-191.9c17.3-15.8 29.1-37.9 31.5-63l.5 .1 0-9.1 0-.5 0-79.5 3.1 0 29.8 59.6 3.6 7.2 7.2-3.6 80-40 4.9-2.5-.5-5.5-10.7-112-.2-2L564 59.6 534.9 16 552 16l8 0 0-16-8 0L524.3 0 520 0 472 0 456 0l-8 0C375.6 0 316.4 56.6 312.2 128L248 128l-56.2 0zM512 80a16 16 0 1 0 -32 0 16 16 0 1 0 32 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHorseSaddle = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;