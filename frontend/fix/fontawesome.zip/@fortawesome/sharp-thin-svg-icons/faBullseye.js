'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'bullseye';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f140';
var svgPathData = 'M256 16a240 240 0 1 1 0 480 240 240 0 1 1 0-480zm0 496A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm0-408a152 152 0 1 1 0 304 152 152 0 1 1 0-304zm0 320a168 168 0 1 0 0-336 168 168 0 1 0 0 336zM200 256a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm128 0a72 72 0 1 0 -144 0 72 72 0 1 0 144 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBullseye = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;