'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'file-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e3a6';
var svgPathData = 'M320 496L16 496 16 16l192 0 0 152 0 8 8 0 104 0 48 0 16 0 0-16L224 0 16 0 0 0 0 16 0 496l0 16 16 0 304 0 0-16zM224 22.6L361.4 160 224 160l0-137.4zM464 208c26.5 0 48 21.5 48 48l0 64-96 0 0-64c0-26.5 21.5-48 48-48zm-64 48l0 64-32 0-16 0 0 16 0 160 0 16 16 0 192 0 16 0 0-16 0-160 0-16-16 0-32 0 0-64c0-35.3-28.7-64-64-64s-64 28.7-64 64zM368 496l0-160 32 0 16 0 96 0 16 0 32 0 0 160-192 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFileLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;