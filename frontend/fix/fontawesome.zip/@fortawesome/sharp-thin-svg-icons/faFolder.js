'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'folder';
var width = 512;
var height = 512;
var aliases = [128193,128447,61716,"folder-blank"];
var unicode = 'f07b';
var svgPathData = 'M272 96L224 32 16 32 0 32 0 48 0 464l0 16 16 0 480 0 16 0 0-16 0-352 0-16-16 0L272 96zm224 16l0 352L16 464 16 48l200 0 43.2 57.6L264 112l8 0 224 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFolder = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;