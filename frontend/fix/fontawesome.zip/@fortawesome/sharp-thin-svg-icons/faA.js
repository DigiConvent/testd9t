'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'a';
var width = 384;
var height = 512;
var aliases = [97];
var unicode = '41';
var svgPathData = 'M186.6 32l-2 5L3.2 480l17.3 0L66.3 368l251.3 0 45.9 112 17.3 0L199.4 37l-2-5-10.7 0zM311.1 352L72.9 352 192 61.1 311.1 352z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faA = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;