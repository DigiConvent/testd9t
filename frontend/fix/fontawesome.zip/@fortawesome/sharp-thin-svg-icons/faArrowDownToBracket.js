'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'arrow-down-to-bracket';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e094';
var svgPathData = 'M229.7 349.7l-5.7 5.7-5.7-5.7-136-136L76.7 208 88 196.7l5.7 5.7L216 324.7 216 8l0-8 16 0 0 8 0 316.7L354.3 202.3l5.7-5.7L371.3 208l-5.7 5.7-136 136zM16 328l0 168 416 0 0-168 0-8 16 0 0 8 0 176 0 8-8 0L8 512l-8 0 0-8L0 328l0-8 16 0 0 8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArrowDownToBracket = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;