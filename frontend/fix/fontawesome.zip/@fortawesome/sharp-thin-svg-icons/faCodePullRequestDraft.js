'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'code-pull-request-draft';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e3fa';
var svgPathData = 'M128 16l0 96-96 0 0-96 96 0zM32 0L16 0l0 16 0 96 0 16 16 0 40 0 0 256-40 0-16 0 0 16 0 96 0 16 16 0 96 0 16 0 0-16 0-96 0-16-16 0-40 0 0-256 40 0 16 0 0-16 0-96 0-16L128 0 32 0zm0 400l96 0 0 96-96 0 0-96zm288 0l96 0 0 96-96 0 0-96zm-16-16l0 16 0 96 0 16 16 0 96 0 16 0 0-16 0-96 0-16-16 0-96 0-16 0zm88-168l0 48-48 0 0-48 48 0zm-48-16l-16 0 0 16 0 48 0 16 16 0 48 0 16 0 0-16 0-48 0-16-16 0-48 0zm0-144l48 0 0 48-48 0 0-48zM328 40l0 16 0 48 0 16 16 0 48 0 16 0 0-16 0-48 0-16-16 0-48 0-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCodePullRequestDraft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;