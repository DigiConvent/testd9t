'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'cowbell';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f8b3';
var svgPathData = 'M136 0l-8 0 0 8 0 88L64 96 3.2 400 0 416l16.3 0 415.4 0 16.3 0-3.2-16L384 96l-64 0 0-88 0-8-8 0L136 0zM304 96L144 96l0-80 160 0 0 80zM136 112l176 0 58.9 0 57.6 288-409 0L77.1 112l58.9 0zm24 336c0 35.3 28.7 64 64 64s64-28.7 64-64l-16 0c0 26.5-21.5 48-48 48s-48-21.5-48-48l-16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCowbell = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;