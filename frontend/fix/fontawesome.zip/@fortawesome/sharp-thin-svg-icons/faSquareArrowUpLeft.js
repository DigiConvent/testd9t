'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'square-arrow-up-left';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e263';
var svgPathData = 'M16 48l0 416 416 0 0-416L16 48zM0 32l16 0 416 0 16 0 0 16 0 416 0 16-16 0L16 480 0 480l0-16L0 48 0 32zM136 160l144 0 8 0 0 16-8 0-124.7 0L317.7 338.3l5.7 5.7L312 355.3l-5.7-5.7L144 187.3 144 312l0 8-16 0 0-8 0-144 0-8 8 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareArrowUpLeft = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;