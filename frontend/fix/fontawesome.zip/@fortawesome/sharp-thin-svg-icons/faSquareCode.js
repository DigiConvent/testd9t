'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'square-code';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e267';
var svgPathData = 'M432 48l0 416L16 464 16 48l416 0zM16 32L0 32 0 48 0 464l0 16 16 0 416 0 16 0 0-16 0-416 0-16-16 0L16 32zM260.7 176l5.7 5.7L340.7 256l-74.3 74.3-5.7 5.7L272 347.3l5.7-5.7 80-80 5.7-5.7-5.7-5.7-80-80-5.7-5.7L260.7 176zm-79 5.7l5.7-5.7L176 164.7l-5.7 5.7-80 80L84.7 256l5.7 5.7 80 80 5.7 5.7L187.3 336l-5.7-5.7L107.3 256l74.3-74.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareCode = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;