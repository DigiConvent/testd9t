'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'star-shooting';
var width = 512;
var height = 512;
var aliases = [127776];
var unicode = 'e036';
var svgPathData = 'M309.7 21.7l-72 72L232 99.3 220.7 88l5.7-5.7 72-72L304 4.7 315.3 16l-5.7 5.7zm192 0l-168 168-5.7 5.7L316.7 184l5.7-5.7 168-168L496 4.7 507.3 16l-5.7 5.7zm0 192l-72 72-5.7 5.7L412.7 280l5.7-5.7 72-72 5.7-5.7L507.3 208l-5.7 5.7zM202.4 162.1l50.9 103.1L367 281.7l19.9 2.9-14.4 14.1-82.3 80.2 19.4 113.3L313 512l-17.8-9.4L193.5 449.1 91.7 502.6 73.9 512l3.4-19.9L96.7 378.9 14.4 298.6 0 284.6l19.9-2.9 113.7-16.5 50.9-103.1 8.9-18.1 8.9 18.1zM251 281l-8.3-1.2-3.7-7.5-45.4-92.1L148 272.2l-3.7 7.5L136 281 34.4 295.7l73.5 71.7 6 5.9-1.4 8.3L95.1 482.8 186 435l7.4-3.9 7.4 3.9 90.9 47.8L274.4 381.6l-1.4-8.3 6-5.9 73.5-71.7L251 281z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faStarShooting = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;