'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'shop';
var width = 640;
var height = 512;
var aliases = ["store-alt"];
var unicode = 'f54f';
var svgPathData = 'M624 224l16 0 0-16 0-32L544 0 96 0 0 176l0 32 0 16 16 0 48 0 0 280 0 8 8 0 304 0 8 0 0-8 0-248-16 0 0 240L80 496l0-272 480 0 0 272-48 0 0-240-16 0 0 248 0 8 8 0 64 0 8 0 0-8 0-280 48 0zM105.5 16l429 0L624 180.1l0 27.9L16 208l0-27.9L105.5 16zM128 376l0 8 8 0 176 0 8 0 0-8 0-120-16 0 0 112-160 0 0-112-16 0 0 120z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faShop = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;