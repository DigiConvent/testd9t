'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'square-s';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'e27d';
var svgPathData = 'M16 48l0 416 416 0 0-416L16 48zM0 32l16 0 416 0 16 0 0 16 0 416 0 16-16 0L16 480 0 480l0-16L0 48 0 32zM145 183.7c-2 10.6-.7 18.6 2.4 25c3.1 6.5 8.6 12 16.2 16.9c15.6 10 38.2 16.2 62.6 22.8l.9 .2c23.3 6.3 48.3 13 66.2 24.5c9.2 5.9 17.1 13.5 21.9 23.3c4.9 9.9 6.2 21.5 3.7 34.9c-4.2 22.2-20.2 37.1-41.5 45.1c-21.1 8-48.1 9.5-76.6 5.4c0 0 0 0 0 0c-17.9-2.7-49.4-11.6-65.9-16.7l-7.6-2.3 4.7-15.3 7.6 2.3c16.6 5.1 47 13.7 63.6 16.1c26.8 3.9 50.9 2.1 68.7-4.6c17.6-6.6 28.5-17.8 31.4-33.1c2-10.6 .7-18.6-2.4-25c-3.1-6.5-8.6-12-16.2-16.9c-15.6-10-38.2-16.2-62.6-22.8l-.9-.2c-23.3-6.3-48.3-13-66.2-24.5c-9.2-5.9-17.1-13.5-21.9-23.3c-4.9-9.9-6.2-21.5-3.7-34.9c4.2-22.2 20.2-37.1 41.5-45.1c21.1-8 48.1-9.5 76.6-5.4c8.8 1.3 27.7 5.2 36.5 7.3l7.8 1.9L287.8 155l-7.8-1.9c-8.5-2.1-26.9-5.9-35-7c-26.8-3.9-50.9-2.1-68.7 4.6c-17.6 6.6-28.5 17.8-31.4 33.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareS = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;