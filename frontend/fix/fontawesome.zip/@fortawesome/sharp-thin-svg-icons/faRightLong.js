'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'right-long';
var width = 512;
var height = 512;
var aliases = ["long-arrow-alt-right"];
var unicode = 'f30b';
var svgPathData = 'M336 216l-16 0L16 216l0 80 304 0 16 0 0 16 0 88 9.4 0 144-144-144-144-9.4 0 0 88 0 16zM352 96L500.7 244.7 512 256l-11.3 11.3L352 416l-16 0-16 0 0-16 0-72 0-16-16 0L16 312 0 312l0-16 0-80 0-16 16 0 288 0 16 0 0-16 0-72 0-16 16 0 16 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faRightLong = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;