'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'table-tree';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e293';
var svgPathData = 'M16 48l0 112 480 0 0-112L16 48zm0 128l0 288 480 0 0-288-384 0 0 96 72 0 8 0 0 16-8 0-72 0 0 80 136 0 8 0 0 16-8 0-144 0-8 0 0-8 0-88 0-8 0-104-80 0zM0 32l16 0 480 0 16 0 0 16 0 416 0 16-16 0L16 480 0 480l0-16L0 48 0 32zM224 272l192 0 0 16-192 0 0-16zm192 96l0 16-128 0 0-16 128 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTableTree = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;