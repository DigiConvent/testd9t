'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fast';
var iconName = 'file-slash';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e3a7';
var svgPathData = 'M512 160L352 0 144 0 128 0l0 12.7 16 12.6 0-9.3 192 0 0 152 0 8 8 0 152 0 0 127.2 16 12.6L512 160zM144 496l0-287.2-16-12.6L128 496l0 16 16 0 352 0 16 0 0-12.7-16-12.6 0 9.3-352 0zM489.4 160L352 160l0-137.4L489.4 160zM16.2 5L9.9 0 0 12.5l6.3 5L623.8 507l6.3 5 9.9-12.5-6.3-5L16.2 5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFileSlash = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;