export { default as FontAwesomeIcon } from './components/FontAwesomeIcon'
export { default as FontAwesomeLayers } from './components/FontAwesomeLayers'
export { default as FontAwesomeLayersText } from './components/FontAwesomeLayersText'
